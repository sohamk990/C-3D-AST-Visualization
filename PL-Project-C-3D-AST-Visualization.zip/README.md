Follow these steps to run our program:
1)Download the zip file and decompress it.
2)Open terminal and navigate to the project directory.
3)make sure you have flex and bison installed in your pc. If not, use ”sudo apt install flex” and then ”sudo apt install bison”.
4) Open the ”hello.txt” file and copy your input program into it. (We are sorry for not making this interactive)
5) enter ”make clean” command.
6) enter ”make all” command.
7) enter ”./Generate” command.
8) Copy numerical values from output.txt to this.tree variable in tree.js.
9) Copy strings values from output.txt to this.value variable in tree.js file.
10) This is hard coded as JavaScript does not have access to local files.
11) run index.html.
